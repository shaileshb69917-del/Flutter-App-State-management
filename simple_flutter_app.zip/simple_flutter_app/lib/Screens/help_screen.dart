import 'package:flutter/material.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Help & Instructions"),
      ),
      body: ListView(
        children: const [
          ExpansionTile(
            title: Text("How to Login"),
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  "1. Open the app.\n"
                  "2. Enter your email and password.\n"
                  "3. Tap the Login button.",
                ),
              ),
            ],
          ),
          ExpansionTile(
            title: Text("How to Register"),
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  "1. Click Sign Up.\n"
                  "2. Fill in your details.\n"
                  "3. Submit the registration form.",
                ),
              ),
            ],
          ),
          ExpansionTile(
            title: Text("Forgot Password"),
            children: [
              Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  "1. Tap Forgot Password.\n"
                  "2. Enter your email.\n"
                  "3. Follow the reset link sent to your email.",
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}