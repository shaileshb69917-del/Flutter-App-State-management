import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/task_provider.dart';
import '../widgets/task_tile.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  final TextEditingController controller =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    final provider =
        Provider.of<TaskProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Task Tracker'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration:
                        const InputDecoration(
                      hintText: 'Enter Task',
                      border:
                          OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    provider.addTask(
                        controller.text);
                    controller.clear();
                  },
                  child: const Text("Add"),
                ),
              ],
            ),
          ),

          Text(
            "Completed Tasks: ${provider.completedCount}",
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          Expanded(
            child: provider.tasks.isEmpty
                ? const Center(
                    child:
                        Text("No Tasks Added"),
                  )
                : ListView.builder(
                    itemCount:
                        provider.tasks.length,
                    itemBuilder:
                        (context, index) {
                      return TaskTile(
                          index: index);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}