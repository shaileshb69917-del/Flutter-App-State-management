import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/task_provider.dart';

class TaskTile extends StatelessWidget {
  final int index;

  const TaskTile({
    super.key,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TaskProvider>(context);

    final task = provider.tasks[index];

    return ListTile(
      leading: Checkbox(
        value: task.isCompleted,
        onChanged: (_) {
          provider.toggleTask(index);
        },
      ),
      title: Text(
        task.title,
        style: TextStyle(
          decoration: task.isCompleted
              ? TextDecoration.lineThrough
              : TextDecoration.none,
        ),
      ),
      trailing: IconButton(
        icon: const Icon(
          Icons.delete,
          color: Colors.red,
        ),
        onPressed: () {
          provider.deleteTask(index);
        },
      ),
    );
  }
}